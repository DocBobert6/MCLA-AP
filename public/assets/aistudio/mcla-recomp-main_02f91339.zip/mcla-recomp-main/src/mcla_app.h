// mcla - ReXGlue Recompiled Project
//
// Customize your app by overriding virtual hooks from rex::ReXApp.

#pragma once

#include <filesystem>

#include <rex/rex_app.h>

#include "achievement_toast.h"

class MclaApp : public rex::ReXApp {
 public:
  using rex::ReXApp::ReXApp;

  static std::unique_ptr<rex::ui::WindowedApp> Create(
      rex::ui::WindowedAppContext& ctx) {
    return std::unique_ptr<MclaApp>(new MclaApp(ctx, "mcla",
        PPCImageConfig));
  }

 protected:
  void OnConfigurePaths(rex::PathConfig& paths) override;
  // A game folder named by game_data_root in mcla.toml that is gone, or has lost files, stops the start with a
  // message that says which folder; the SDK's own check says only that a folder does not exist.
  bool ConstructRuntime(const rex::PathConfig& paths) override;
  void OnPreSetup(rex::RuntimeConfig& config) override;
  void OnPostSetup() override;
  void OnCreateDialogs(rex::ui::ImGuiDrawer* drawer) override;
  void OnShutdown() override;
  void OnPreLaunchModule() override;
  // The shader storage: the pack's import is done before the module starts (OnPreLaunchModule),
  // the stamp written once the SDK created the stored pipelines, and a preparation run
  // (--mcla_prepare_shaders) quits here instead of starting (src/shader_prepare.cpp).
  void OnPostLaunchModule(rex::system::XThread* thread) override;
  // Saves what was changed in the pause menu's settings, in case the window is
  // closed while one of its submenus is open (src/settings_menu.cpp).
  bool OnWindowCloseRequested() override;
  // The game's main thread has ended (the title quit on its own, or the window's close ended it): the pump
  // thread's audio watchdog stops counting silences (src/poll_wait.cpp).
  void OnGuestThreadExit(rex::system::XThread* thread) override;

  // Achievement pop-ups, registered with the ImGui drawer only while one is
  // on screen (src/achievement_toast.h). The SDK's toast is registered for the
  // whole session, which made the presenter repaint at the monitor's refresh
  // rate whatever the frame cap.
  std::unique_ptr<rex::ui::AchievementNotificationDialog> CreateAchievementNotificationDialog()
      override {
    return mcla::MakeOnDemandToast(rex::ReXApp::CreateAchievementNotificationDialog(),
                                   imgui_drawer(), app_context());
  }

 private:
  std::unique_ptr<rex::ui::ImGuiDialog> video_borders_;
  void InstallCrashTrace();
  void ConfigureFrameTiming();
  void ApplyPcDefaults();
  void FollowCursorSetting();
  void StartProfilerIfRequested();

  // The game folder and the mcla.toml it came from, when mcla.toml named it (empty otherwise).
  std::filesystem::path configured_game_root_;
  std::filesystem::path configured_game_root_file_;
};
