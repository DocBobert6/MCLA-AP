#!/usr/bin/env bash
# One command from your own disc image to the game installed on a PS5.
#
#   sudo bash ps5/make_ps5.sh --iso /path/to/your.iso [--console 192.168.1.50]
#
# Host: Arch Linux, as root (a fresh Arch under WSL2 on Windows is the tested
# setup; docs/building.md, 'PS5', walks through it). Everything is built on
# your machine from your own copy of the game: nothing of the game is in this
# repository, and what this script produces from it is yours to keep, not to
# share.
#
# Every step is skipped when its result is already there, so the script can be
# run again after a failure, or after a change, and continues from that step.
#
#   --iso PATH        your disc image (Midnight Club: Los Angeles Complete
#                     Edition, USA/Europe, Xbox 360). Not needed once game/
#                     has been extracted.
#   --console IP      upload the title and the game data to the console (FTP)
#   --ftp-port N      the console's FTP port (default 2121)
#   --title-id ID     the title's id on the console (default PPSA99779)
#   --tile IMAGE      your own picture for the home-screen tile (any common
#                     format; it is resized to 512x512)
#   --theme FILE.at9  your own home-screen theme (ATRAC9, 48 kHz stereo)
#   --art-dir DIR     your own tile, backgrounds and theme in the console's
#                     formats (icon0.png, pic0.dds, pic1.dds, snd0.at9)
#                     instead of the art made from the disc
#   --test-build      keep the test scaffolding (waits for a log connection)
#   --jobs N          parallel compile jobs (default: all cores)
#
# Locations, changeable through the environment:
#   PS5VK   (/root/ps5vk)   the Vulkan driver project and its toolchain
#   WORK    (/root/mcla)    the SDK checkout and all build trees
#   MCLA_PS5_FSR (1)       0: without FSR 3.1 anti-aliasing (untested on the console,
#                           offered for the next start; MSAA stays the default)
#   MCLA_PS5_FRAMEGEN (1)  0: without FSR 3.1 frame generation (untested on the console,
#                           offered for the next start, off by default; FSR
#                           anti-aliasing stays). Needs MCLA_PS5_FSR=1 to matter.
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
repo=$(cd -- "$here/.." && pwd)
PS5VK=${PS5VK:-/root/ps5vk}
WORK=${WORK:-/root/mcla}
driver="$PS5VK/PS5_Vulkan"
sdk="$driver/.deps/native/ps5-payload-sdk"
rex_src="$WORK/rexglue-sdk"
rex_build="$WORK/build-ps5"
rex_host="$WORK/build-host"
rex_tag=v0.10.0
rex_commit=f5337cdc947ff6d4c4196737e2c807a48f2a1fc2

iso= console= ftp_port=2121 title_id=PPSA99779 art_dir= tile= theme= play=1 jobs=$(nproc)
while [ $# -gt 0 ]; do
    case $1 in
        --iso) iso=$2; shift 2 ;;
        --console) console=$2; shift 2 ;;
        --ftp-port) ftp_port=$2; shift 2 ;;
        --title-id) title_id=$2; shift 2 ;;
        --art-dir) art_dir=$2; shift 2 ;;
        --tile) tile=$2; shift 2 ;;
        --theme) theme=$2; shift 2 ;;
        --test-build) play=; shift ;;
        --jobs) jobs=$2; shift 2 ;;
        -h|--help) sed -n '2,34p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) echo "unknown option: $1 (see --help)" >&2; exit 2 ;;
    esac
done

step() { printf '\n==> %s\n' "$*"; }
fail() { printf '\nFAILED: %s\n' "$*" >&2; exit 1; }
mkdir -p "$WORK"
logs="$WORK/logs"; mkdir -p "$logs"
# Run a long command with its output in a log; on failure show the end of it.
logged() {
    local name=$1; shift
    if ! "$@" > "$logs/$name.log" 2>&1; then
        tail -25 "$logs/$name.log" >&2
        fail "$name (full log: $logs/$name.log)"
    fi
}

[ "$(id -u)" -eq 0 ] || fail "run as root (the driver project's build installs packages and writes under /root)"
command -v pacman > /dev/null || fail "this script needs Arch Linux (pacman); see docs/building.md, 'PS5'"

# ---------------------------------------------------------------------------
step "1/9 host packages"
# The X11 packages are for the recompiler's own build: it is a command-line
# tool, but the SDK configures its window library along with everything else.
logged packages pacman -Sy --noconfirm --needed base-devel clang llvm lld cmake ninja git curl rsync python \
    python-pillow ffmpeg unzip libx11 libxext libxi libxcursor libxrandr libxinerama libxss libxkbcommon \
    libxtst libxfixes libxrender mesa

# ---------------------------------------------------------------------------
step "2/9 PS5 toolchain and Vulkan driver (about 20 minutes the first time)"
if [ -f "$driver/.deps/native/radv-release/lib/libvulkan_radeon.ps5.a" ] && [ -x "$driver/build/host/ps5-native-tool" ]; then
    echo "already built: $driver"
else
    [ "$PS5VK" = /root/ps5vk ] || fail "the driver build script works in /root/ps5vk; leave PS5VK unset"
    bash "$here/build_ps5_vulkan_driver.sh" || true
    grep -q "ALL STEPS DONE" /root/ps5vk-arch.log || { tail -25 /root/ps5vk-arch.log >&2; fail "driver build (log: /root/ps5vk-arch.log)"; }
fi
[ -f "$sdk/toolchain/prospero.cmake" ] || fail "the PS5 toolchain is missing under $sdk"

# ---------------------------------------------------------------------------
step "3/9 ReXGlue SDK $rex_tag with this project's patches"
# A patch revised later still adds the name the SDK is checked for, so the
# SHA-256 of every patch applied goes into the SDK's .mcla-patches, and a patch
# that is in without its current hash there stops the build: the SDK has to be
# patched afresh, as reverting an older version can fail where later patches
# change the same lines.
records="$rex_src/.mcla-patches"
patch_hash() { sha256sum < "$1" | cut -d' ' -f1; }
record_patch() {
    local leaf; leaf=$(basename "$1")
    { grep -v " $leaf\$" "$records" 2> /dev/null || true; echo "$(patch_hash "$1") $leaf"; } > "$records.new"
    mv "$records.new" "$records"
}
check_patch() {
    local leaf record again; leaf=$(basename "$1")
    again="Patch the SDK afresh: delete $rex_src and run this again."
    record=$(grep " $leaf\$" "$records" 2> /dev/null | head -1 | cut -d' ' -f1 || true)
    [ -n "$record" ] || fail "$leaf is in the SDK without a record in $records: it was patched by an older make_ps5.sh and may hold an older version of it. $again"
    [ "$record" = "$(patch_hash "$1")" ] || fail "patches/$leaf has changed since it was applied to the SDK. $again"
}
if [ ! -f "$rex_src/.mcla-patched" ]; then
    if [ ! -d "$rex_src/.git" ]; then
        logged sdk-clone git clone --recursive --branch "$rex_tag" https://github.com/rexglue/rexglue-sdk.git "$rex_src"
    fi
    [ "$(git -C "$rex_src" rev-parse HEAD)" = "$rex_commit" ] || fail "the SDK checkout is not $rex_tag ($rex_commit)"
    git -C "$rex_src" apply "$repo/patches/rexglue-v0.10.0-mcla.patch" || fail "SDK patch does not apply (is the checkout clean?)"
    record_patch "$repo/patches/rexglue-v0.10.0-mcla.patch"
    git -C "$rex_src/thirdparty/FFmpeg" apply "$repo/patches/rexglue-ffmpeg-ps5-config.patch" || fail "FFmpeg patch does not apply"
    record_patch "$repo/patches/rexglue-ffmpeg-ps5-config.patch"
    touch "$rex_src/.mcla-patched"
else
    echo "already patched: $rex_src"
    check_patch "$repo/patches/rexglue-v0.10.0-mcla.patch"
    check_patch "$repo/patches/rexglue-ffmpeg-ps5-config.patch"
fi
# The car reflection fix came later than the patches above:
# an SDK patched before it gets it here, and step 6 builds what changed.
if ! grep -q kSysFlag_MinMaxColor0TimesSrcAlpha "$rex_src/include/rex/graphics/pipeline/shader/spirv_translator.h"; then
    git -C "$rex_src" apply "$repo/patches/rexglue-minmax-blend-factor.patch" || fail "the reflection fix does not apply (is the checkout clean?)"
    record_patch "$repo/patches/rexglue-minmax-blend-factor.patch"
    echo "applied: rexglue-minmax-blend-factor.patch"
else
    check_patch "$repo/patches/rexglue-minmax-blend-factor.patch"
fi
# Short waits that spun instead of sleeping (from the Linux build, PR #4): the
# PS5 runs the same POSIX threading code. Added later, so applied the same way.
if ! grep -q "Sleep the real remaining time" "$rex_src/src/core/threading_posix.cpp"; then
    git -C "$rex_src" apply "$repo/patches/rexglue-linux-wait-sleep.patch" || fail "the wait fix does not apply (is the checkout clean?)"
    record_patch "$repo/patches/rexglue-linux-wait-sleep.patch"
    echo "applied: rexglue-linux-wait-sleep.patch"
else
    check_patch "$repo/patches/rexglue-linux-wait-sleep.patch"
fi

# Later patches to the SDK (patches/README.md), applied in the order they were
# made, as several change neighbouring lines. Each goes onto an SDK patched
# before it existed, found by a name it adds; one that is in already must be
# the version recorded (check_patch). Built and run on Windows only so far.
while read -r patch file adds; do
    # -s: a patch that adds its file is not in while the file isn't there.
    if grep -qsF "$adds" "$rex_src/$file"; then
        check_patch "$repo/patches/$patch"
        continue
    fi
    # nowarn: rebuilt shader headers keep the compiler listing's trailing spaces.
    git -C "$rex_src" apply --whitespace=nowarn "$repo/patches/$patch" || fail "$patch does not apply (is the checkout clean?)"
    record_patch "$repo/patches/$patch"
    echo "applied: $patch"
done <<'LATER'
rexglue-gpu-regwrite-bulk.patch src/graphics/command_processor.cpp gpu_regwrite_bulk
rexglue-imgui-dialog-repaint-on-demand.patch include/rex/ui/imgui_dialog.h RepaintsContinuously
rexglue-inline-bit-helpers.patch include/rex/math.h Out of line in rexruntime
rexglue-perf-counters-batched.patch src/graphics/command_processor.cpp gpu_batch_perf_counters
rexglue-shared-memory-request-fast-path.patch src/graphics/shared_memory.cpp shared_memory_request_fast_path
rexglue-threaded-submission-d3d12.patch src/graphics/d3d12/command_processor.cpp d3d12_threaded_submission
rexglue-timer-queue-blocking-wait.patch src/core/timer_queue.cpp timer_queue_blocking_wait
rexglue-shared-memory-fast-path-hot-pages.patch src/graphics/shared_memory.cpp shared_memory_request_fast_path_with_hot_pages
rexglue-hot-pages-watched-ranges.patch src/graphics/shared_memory.cpp Watching wins
rexglue-cursor-auto-hide.patch src/ui/window.cpp RequestAutoHiddenCursorHide
rexglue-vulkan-memexport-check-order.patch src/graphics/vulkan/command_processor.cpp most draws export nothing
rexglue-vulkan-hoist-shared-memory-uploads.patch src/graphics/vulkan/command_processor.cpp vulkan_hoist_shared_memory_uploads
rexglue-threaded-submission-vulkan.patch src/graphics/vulkan/command_processor.cpp vulkan_threaded_submission
rexglue-d3d12-placed-texture-heaps.patch src/graphics/d3d12/texture_cache.cpp d3d12_texture_heaps
rexglue-vulkan-texture-load-storage-copy.patch src/graphics/vulkan/texture_cache.cpp vulkan_texture_load_storage_copy
rexglue-clear-rectangle-draws.patch src/graphics/pipeline/render_target/cache.cpp clear_rectangle_draws
rexglue-texture-load-direct.patch src/graphics/pipeline/texture/cache.cpp texture_load_direct
rexglue-async-pipelines-no-frame-wait.patch src/graphics/command_processor.cpp async_pipeline_wait_budget_ms
rexglue-vulkan-pipeline-storage-parallel-translation.patch src/graphics/vulkan/pipeline_cache.cpp vulkan_pipeline_storage_translation_threads
rexglue-vulkan-pipeline-cache-file.patch src/graphics/vulkan/pipeline_cache.cpp vulkan_pipeline_cache_file
rexglue-resolve-4xmsaa-depth-samples.patch src/graphics/shaders/bytecode/d3d12_5_1/resolve_fast_32bpp_4xmsaa_cs.h Approximately 200 instruction slots used
rexglue-direct-resolve.patch src/graphics/pipeline/render_target/cache.cpp GetDirectResolveSource
rexglue-cvar-toml-strings.patch src/core/cvar.cpp LoadConfigByLine
rexglue-edram-size.patch src/graphics/pipeline/render_target/cache.cpp edram_tiles
rexglue-guest-markers.patch include/rex/graphics/command_processor.h OnGuestMarker
rexglue-hdr-output.patch src/ui/presenter.cpp IsHdrOutputWanted
rexglue-hdr-ui-layer.patch src/graphics/command_processor.cpp HdrBeforeResolve
rexglue-hdr-scene-mcla.patch src/graphics/command_processor.cpp HdrPrepareScene
rexglue-temporal-aa.patch include/rex/graphics/command_processor.h TaaJitterNdcOffset
rexglue-temporal-aa-shaders-vk.patch thirdparty/fidelityfx-shaders-vk/rexglue_fsr_shaders_vk.h REXGLUE_FSR_SHADERS_VK_FLAGS
rexglue-fullscreen-setting-ui-thread.patch src/ui/rex_app.cpp after the lock is released
rexglue-presenter-ui-overlay.patch src/ui/vulkan/vulkan_presenter_ui_overlay.cpp CreateUIOverlayFromUIThread
rexglue-frame-generation.patch src/ui/vulkan/vulkan_presenter_frame_generation.cpp FramePacerThread
rexglue-vulkan-paint-pipeline-format.patch src/ui/vulkan/vulkan_presenter.cpp swapchain_effect_pipeline.swapchain_format =
rexglue-vulkan-present-semaphore-per-image.patch src/ui/vulkan/vulkan_presenter.cpp swapchain_present_semaphores.push_back
rexglue-d3d12-storage-preload-threads.patch src/graphics/d3d12/pipeline_cache.cpp creation_threads_.size() < creation_thread_needed_count
rexglue-vulkan-pipeline-storage-keep-unsupported.patch src/graphics/vulkan/pipeline_cache.cpp pipeline_storage_valid_count
rexglue-shader-storage-prepare.patch src/graphics/shader_storage_progress.h ShaderStorageProgress
rexglue-content-header-padding.patch src/system/xam/content_manager.cpp Written as zeros.
rexglue-user-name.patch src/system/xam/user_profile.cpp ProfileNameFromCvar
rexglue-low-latency.patch src/ui/low_latency.cpp LowLatency::OnFrameStart
rexglue-frame-generation-nonwindows.patch src/ui/vulkan/vulkan_presenter_frame_generation.cpp frame_generation_pacing
rexglue-threaded-submission-d3d12-idle-wait.patch src/graphics/d3d12/command_processor.cpp d3d12_threaded_submission_idle_wait
rexglue-fsr-upscaling.patch include/rex/graphics/command_processor.h TaaResolveStretch
rexglue-guest-atomics-lock-free.patch src/core/mutex.cpp guest_atomics_lock_free
rexglue-resolve-direct-batched-loads.patch src/graphics/pipeline/render_target/cache.cpp resolve_direct_batched_loads
rexglue-skip-overwritten-transfers.patch src/graphics/pipeline/render_target/cache.cpp skip_overwritten_transfers
rexglue-d3d12-depth-resolve-read-state.patch src/graphics/d3d12/render_target_cache.cpp d3d12_depth_resolve_read_state
rexglue-xma-decoder-fixes.patch src/audio/xma_context.cpp xma_race_fixes
rexglue-alpha-to-mask-tolerance.patch src/graphics/flags.cpp alpha_to_mask_tolerance
rexglue-resolve-downscale-unit-layout.patch src/graphics/command_processor.cpp resolve_downscale_unit_layout
rexglue-resolve-readback-rules.patch src/graphics/command_processor.cpp readback_resolve_rules
rexglue-resolve-unscaled-copy.patch src/graphics/command_processor.cpp resolve_unscaled_copy_rules
rexglue-vulkan-odepth-scale.patch src/graphics/flags.cpp vulkan_odepth_float24_scale
rexglue-render-target-max-height.patch src/graphics/pipeline/render_target/cache.cpp render_target_max_height
rexglue-render-target-trim.patch src/graphics/pipeline/render_target/cache.cpp render_target_trim_seconds
rexglue-gpu-memory.patch src/graphics/command_processor.cpp gpu_memory_log_ms
rexglue-d3d12-hoist-shared-memory-uploads.patch src/graphics/d3d12/command_processor.cpp d3d12_hoist_shared_memory_uploads
rexglue-texture-load-direct-unscaled.patch src/graphics/pipeline/texture/cache.cpp texture_load_direct_unscaled
rexglue-occlusion-queries.patch src/graphics/command_processor.cpp occlusion_query_async
rexglue-upstream-storage-flush.patch src/graphics/vulkan/pipeline_cache.cpp waiting first would
rexglue-upstream-host-fp-state.patch include/rex/ppc/context.h Keep host FP exceptions masked on every write
rexglue-upstream-linux-wine.patch src/core/dynlib_win.cpp GetModuleHandleExW
rexglue-upstream-small-fixes.patch include/rex/system/xam/user_profile.h Settings are owned, and replaced, through
rexglue-codegen-csr-lazy.patch src/codegen/config.cpp csr_mode_free_ops
rexglue-affinity-warning-once.patch src/system/xthread.cpp affinity_warning_once
rexglue-d3d12-msaa-line-guard.patch src/graphics/d3d12/command_processor.cpp d3d12_msaa_line_guard
LATER

# ---------------------------------------------------------------------------
step "4/9 the recompiler (rexglue), for this machine"
rexglue=$(find "$rex_host" "$rex_src/out" -maxdepth 4 -name rexglue -type f -perm -u+x 2> /dev/null | head -1 || true)
if [ -z "$rexglue" ]; then
    logged host-configure cmake -S "$rex_src" -B "$rex_host" -G Ninja -DCMAKE_BUILD_TYPE=Release \
        -DCMAKE_C_COMPILER=clang -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_CXX_STANDARD=23 \
        -DCMAKE_C_FLAGS=-march=x86-64-v2 -DCMAKE_CXX_FLAGS=-march=x86-64-v2 \
        -DREXGLUE_USE_VULKAN=ON -DREXGLUE_ENABLE_TRACY=OFF -DREXGLUE_BUILD_TESTS=OFF
    logged host-build ninja -C "$rex_host" -j "$jobs" rexglue
    rexglue=$(find "$rex_host" "$rex_src/out" -maxdepth 4 -name rexglue -type f -perm -u+x | head -1)
fi
[ -x "$rexglue" ] || fail "the recompiler was not built"
echo "recompiler: $rexglue"

# ---------------------------------------------------------------------------
step "5/9 your game: extract from the disc image, then recompile its code"
if [ ! -f "$repo/game/default.xex" ]; then
    [ -n "$iso" ] || fail "game/ is empty: give your disc image with --iso"
    [ -f "$iso" ] || fail "no such file: $iso"
    logged extract python3 "$repo/scripts/extract_game.py" "$iso" "$repo/game"
fi
[ -f "$repo/game/default.xex" ] || fail "game/default.xex is missing after extraction"
# The recompiled code depends on the hook and function lists in config/ and on
# the recompiler: regenerate when any of them is newer than the result.
stamp="$repo/generated/default/.generated"
if [ ! -f "$stamp" ] || [ -n "$(find "$repo/config" "$repo/mcla_manifest.toml" "$rexglue" -newer "$stamp" -print -quit)" ]; then
    ( cd "$repo" && logged codegen "$rexglue" codegen mcla_manifest.toml )
    grep -q 'REX_PLATFORM_PS5' "$repo/generated/default/mcla_pch.h" || fail "the generated header lacks the PS5 rule (unpatched recompiler?)"
    touch "$stamp"
else
    echo "generated code is up to date"
fi
echo "generated sources: $(ls "$repo"/generated/default/*.cpp | wc -l)"

# ---------------------------------------------------------------------------
step "6/9 the runtime, for PS5"
# FSR 3.1 (rexglue-temporal-aa.patch), unless MCLA_PS5_FSR=0: FidelityFX's
# source is fetched at a pinned commit (needs the network the first time) and
# built as static libraries; if that fails, the runtime builds without FSR. A
# build folder configured with the other choice is configured again.
fsr=${MCLA_PS5_FSR:-1}
case $fsr in 0) fsr_cmake=OFF ;; 1) fsr_cmake=ON ;; *) fail "MCLA_PS5_FSR must be 0 or 1" ;; esac
# Frame generation (rexglue-frame-generation.patch): FidelityFX's optical flow and frame
# interpolation too, in the same static libraries (untested on the console).
# If FidelityFX fails to build with it (a component compiled on no console before), the build
# is made again without it so that FSR anti-aliasing is kept, and that is remembered in the
# build folder (.framegen-failed) until MCLA_PS5_FRAMEGEN=1 is given.
framegen=${MCLA_PS5_FRAMEGEN:-1}
case $framegen in 0) framegen_cmake=OFF ;; 1) framegen_cmake=ON ;; *) fail "MCLA_PS5_FRAMEGEN must be 0 or 1" ;; esac
if [ "${MCLA_PS5_FRAMEGEN:-}" = 1 ]; then
    rm -f "$rex_build/.framegen-failed"
elif [ "$fsr" = 1 ] && [ -z "${MCLA_PS5_FRAMEGEN:-}" ] && [ -f "$rex_build/.framegen-failed" ]; then
    echo "note: frame generation is left out: FidelityFX did not build with it earlier (MCLA_PS5_FRAMEGEN=1, or deleting $rex_build/.framegen-failed, tries again)"
    framegen=0 framegen_cmake=OFF
fi
# (The frame generation switch only exists where FSR is built; the cache has no entry for it
# without FSR.)
if [ ! -f "$rex_build/build.ninja" ] || ! grep -q "^REXGLUE_ENABLE_FSR:BOOL=$fsr_cmake\$" "$rex_build/CMakeCache.txt" \
        || { [ "$fsr" = 1 ] && ! grep -q "^REXGLUE_FSR_FRAMEGEN:BOOL=$framegen_cmake\$" "$rex_build/CMakeCache.txt"; }; then
    # -flto=thin: 5-8% more draws a second on the console.
    logged ps5-configure cmake -S "$rex_src" -B "$rex_build" -G Ninja \
        -DCMAKE_TOOLCHAIN_FILE="$sdk/toolchain/prospero.cmake" \
        -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_STANDARD=23 \
        -DCMAKE_C_FLAGS="-march=znver2 -flto=thin" \
        -DCMAKE_CXX_FLAGS="-march=znver2 -fexperimental-library -flto=thin" \
        -DREXGLUE_USE_D3D12=OFF -DREXGLUE_USE_VULKAN=ON -DREXGLUE_ENABLE_TRACY=OFF -DREXGLUE_ENABLE_FSR=$fsr_cmake \
        $([ "$fsr" = 0 ] || echo "-DREXGLUE_FSR_FRAMEGEN=$framegen_cmake")
fi
logged ps5-runtime ninja -C "$rex_build" -j "$jobs" rexruntime rexgpu-xenos
# FidelityFX built with frame generation, and failed (its runtime's own build leaves the marker
# soft_step.cmake writes): once more without frame generation, which is a smaller part of it and
# the one nothing else needs, so that FSR anti-aliasing is not lost to it.
if [ "$fsr" = 1 ] && [ "$framegen" = 1 ] && [ -f "$rex_build/_deps/ffx-vk-p/failed" ]; then
    echo "warning: FidelityFX did not build with frame generation ($logs/ps5-runtime.log); building it again without (the same as MCLA_PS5_FRAMEGEN=0), so that FSR anti-aliasing is kept" >&2
    framegen=0 framegen_cmake=OFF
    logged ps5-configure-nofg cmake "$rex_build" -DREXGLUE_FSR_FRAMEGEN=OFF
    logged ps5-runtime-nofg ninja -C "$rex_build" -j "$jobs" rexruntime rexgpu-xenos
    # (The runtime's own marker, not the archive: one an earlier build left is still there if this
    # one failed too.)
    if [ ! -f "$rex_build/_deps/ffx-vk-p/failed" ] && [ -f "$rex_src/out/ps5-amd64/libamd_fidelityfx_vk.a" ]; then
        touch "$rex_build/.framegen-failed"
    else
        echo "warning: FidelityFX did not build without frame generation either, so it is not frame generation's code" >&2
    fi
fi
# A FidelityFX runtime that failed to build is not offered, whatever archives an earlier build
# left next to the runtime's.
if [ "$fsr" = 1 ] && [ -f "$rex_build/_deps/ffx-vk-p/failed" ]; then
    rm -f "$rex_src/out/ps5-amd64"/libamd_fidelityfx_*.a "$rex_src/out/ps5-amd64"/libffx_*.a
fi
# FidelityFX's static libraries, next to the runtime's (the game links every
# archive there): none without FSR; and none if they refer to a Vulkan function
# that neither the GPU plugin (src/graphics/vulkan/temporal_aa_static.cpp, as a
# loader would export it) nor the driver defines, as the title couldn't link
# them. Without them the game doesn't offer FSR.
fsr_archives=$(ls "$rex_src/out/ps5-amd64"/libamd_fidelityfx_*.a "$rex_src/out/ps5-amd64"/libffx_*.a 2> /dev/null || true)
if [ "$fsr" = 0 ]; then
    [ -z "$fsr_archives" ] || rm -f $fsr_archives
    echo "FSR: left out (MCLA_PS5_FSR=0)"
elif [ ! -f "$rex_src/out/ps5-amd64/libamd_fidelityfx_vk.a" ]; then
    echo "note: FSR 3.1 was not built (fetching FidelityFX needs the network, or its build failed: $logs/ps5-runtime.log); the game offers MSAA and off. If frame generation's code is what failed to compile, MCLA_PS5_FRAMEGEN=0 leaves it out" >&2
else
    nm=$(command -v llvm-nm || true)
    [ -n "$nm" ] || fail "llvm-nm is missing (pacman -S llvm)"
    radv="$driver/.deps/native/radv-release/lib/libvulkan_radeon.ps5.a"
    wanted=$("$nm" -u -j $fsr_archives 2> /dev/null | grep -E '^vk[A-Z]' | sort -u || true)
    defined=$( { "$nm" --defined-only -j "$rex_src/out/ps5-amd64/librexgpu-xenos.a" 2> /dev/null
                 [ ! -f "$radv" ] || "$nm" --defined-only -j "$radv" 2> /dev/null; } | sort -u || true)
    missing=$(comm -23 <(printf '%s\n' "$wanted") <(printf '%s\n' "$defined") | grep . || true)
    if [ -n "$missing" ]; then
        echo "warning: FidelityFX refers to Vulkan functions nothing in the title defines ($(echo $missing)); building without FSR" >&2
        rm -f $fsr_archives
    else
        echo "FSR: FidelityFX's static libraries built; the Vulkan functions it calls directly: $(echo $wanted)"
        # Frame generation's components are in the same archives (their Vulkan calls are in the
        # audit above); say so when they are not there.
        if [ "$framegen" = 1 ] \
                && { [ ! -f "$rex_src/out/ps5-amd64/libffx_frameinterpolation_x64.a" ] \
                     || [ ! -f "$rex_src/out/ps5-amd64/libffx_opticalflow_x64.a" ]; }; then
            echo "note: FidelityFX's frame interpolation and optical flow libraries were not built; frame generation will fail to start in the game (its row says FAILED); FSR anti-aliasing is not affected" >&2
        fi
    fi
fi

# ---------------------------------------------------------------------------
step "7/9 the title's tile and backgrounds"
if [ -z "$art_dir" ]; then
    art_dir="$WORK/title-art"
    if [ ! -f "$art_dir/icon0.png" ]; then
        # From the dashboard art on your own disc; none is in the repository.
        logged art-extract python3 "$here/make_title_art.py" "$repo/game" "$WORK/title-art-source"
        [ -d "$driver/.deps/native/bc7enc_rdo" ] || ( cd "$driver" && logged art-tools bash tools/setup-asset-dependencies.sh )
        mkdir -p "$art_dir"
        ( cd "$driver" && logged art-convert bash tools/prepare-assets.sh --icon "$WORK/title-art-source/icon.png" \
            --background "$WORK/title-art-source/background.png" --output-directory "$art_dir" )
    else
        echo "already made: $art_dir"
    fi
fi
[ -f "$art_dir/icon0.png" ] || fail "no icon0.png in $art_dir"
# Your own tile or theme over that: kept apart, so the art made from the disc
# is still there for a later build without them.
if [ -n "$tile$theme" ]; then
    [ -z "$tile" ] || [ -f "$tile" ] || fail "no such file: $tile"
    [ -z "$theme" ] || [ -f "$theme" ] || fail "no such file: $theme"
    rm -rf "$WORK/title-art-own"; cp -r "$art_dir" "$WORK/title-art-own"; art_dir="$WORK/title-art-own"
    if [ -n "$tile" ]; then
        python3 - "$tile" "$art_dir/icon0.png" <<'PY' || fail "the tile could not be converted"
import sys
from PIL import Image
Image.open(sys.argv[1]).convert("RGBA").resize((512, 512), Image.LANCZOS).save(sys.argv[2])
PY
    fi
    [ -z "$theme" ] || cp "$theme" "$art_dir/snd0.at9"
    echo "own art: $art_dir"
fi

# ---------------------------------------------------------------------------
step "8/9 the game for PS5 (about 120 large files: 10 to 30 minutes the first time)"
export PS5_VULKAN="$driver" REX_SRC="$rex_src" REX_BUILD="$rex_build" MCLA_PS5_WORK="$WORK/game-ps5" JOBS="$jobs" MCLA_PS5_FSR="$fsr"
export TITLE="$title_id" MCLA_TITLE_NAME="Midnight Club: Los Angeles" ART_DIR="$art_dir"
if [ -n "$play" ]; then
    export MCLA_PLAY=1 MCLA_LOG_LEVEL=warning
else
    export MCLA_RUN_SECONDS=3600
fi
logged game-build bash "$here/game/build.sh" 7
dist="$driver/dist/$title_id"
[ -f "$dist/eboot.bin" ] || fail "no eboot.bin in $dist"
out="$repo/out/ps5-title/$title_id"
rm -rf "$out"; mkdir -p "$(dirname "$out")"; cp -r "$dist" "$out"
echo "title: $out ($(du -sh "$out" | cut -f1))"

# ---------------------------------------------------------------------------
step "9/9 the console"
if [ -z "$console" ]; then
    cat <<EOF
No --console given, so nothing was uploaded. To install by hand, copy
  $out            ->  /data/homebrew/$title_id   on the console
  $repo/game      ->  /data/mcla/game            on the console
and see docs/building.md, 'PS5'.
EOF
    exit 0
fi
ftp="ftp://$console:$ftp_port"
curl -s --max-time 15 "$ftp/data/" > /dev/null || fail "no FTP server at $console:$ftp_port (start one on the console first)"
# The size of a file on the console; nothing if it is not there (curl fails
# then, which must not end the script).
remote_size_of() {
    { curl -s --max-time 30 -I "$ftp$1" 2> /dev/null || true; } | tr -d '\r' | awk '/Content-Length/{print $2}'
}
# Upload a file unless one of the same size is already there.
put() {
    local source=$1 target=$2 local_size remote_size
    local_size=$(stat -c %s "$source")
    remote_size=$(remote_size_of "$target")
    if [ "$local_size" = "$remote_size" ] && [ "${3:-}" != always ]; then
        echo "  same size, kept: $target"
        return
    fi
    echo "  uploading $target ($local_size bytes)"
    # Some consoles' FTP servers write over an existing file without cutting
    # it short, so a smaller new file kept the old file's size and its tail.
    # Remove the old copy first. (Not one of the same size, which "always"
    # uploads again: written over in place, it is exactly the new file.)
    if [ -n "$remote_size" ] && [ "$remote_size" != "$local_size" ]; then
        curl -s --max-time 30 -Q "DELE $target" "$ftp/" > /dev/null 2>&1 || true
        [ -z "$(remote_size_of "$target")" ] || fail "could not replace $target on the console (is the game running? close it and run this again)"
    fi
    # Three tries: a console's FTP server now and then drops a long transfer.
    local attempt
    for attempt in 1 2 3; do
        curl -s -S --ftp-create-dirs -T "$source" "$ftp$target" && break
        [ "$attempt" -lt 3 ] || fail "upload of $target (run the same command again to continue; files already there are kept)"
        echo "  retrying $target"
        sleep 10
    done
    remote_size=$(remote_size_of "$target")
    [ "$local_size" = "$remote_size" ] || fail "$target is $remote_size bytes on the console, $local_size here"
}
echo "game data to /data/mcla/game (6 GB the first time)"
( cd "$repo/game" && find . -type f | sed 's#^\./##' | sort ) | while read -r file; do
    put "$repo/game/$file" "/data/mcla/game/$file"
done
if [ -f "$repo/shaderpack/545407F8.shaderpack" ]; then
    echo "shader pack to /data/mcla/shaderpack (imported at every start)"
    put "$repo/shaderpack/545407F8.shaderpack" "/data/mcla/shaderpack/545407F8.shaderpack" always
fi
echo "title to /data/homebrew/$title_id"
( cd "$out" && find . -type f | sed 's#^\./##' | sort ) | while read -r file; do
    put "$out/$file" "/data/homebrew/$title_id/$file" always
done
cat <<EOF

Done. On the console, "Midnight Club: Los Angeles" appears on the home screen
once your homebrew mounter has picked up /data/homebrew/$title_id (see
docs/building.md, 'PS5').
EOF
