// PS5 port milestone P4: the recompiled game linked with the runtime, started
// without graphics.
//
// The desktop host goes through rex::ReXApp, which is built around a window
// and an event loop. There is neither here yet (presentation is P5), so this
// drives rex::Runtime directly, in the same order ReXApp does: setup, XEX
// load, guest heap, main thread. With no graphics system the game is expected
// to stop when it reaches its video setup; the point of this milestone is that
// the guest entry point runs and kernel calls are logged.
//
// Runs as a payload through the ELF loader, so standard output is the loader's
// socket. Every stage is announced before it starts (see
// docs/ps5-port-plan.md for why).
//
// Stops after MCLA_STAGE, so the first runs on the console can go one stage at
// a time:
//   1  construct the runtime and Setup() (memory, kernel, file systems)
//   2  ... and load the XEX image into guest memory
//   3  ... and create the guest heap and the suspended main thread
//   4  ... and resume the main thread, then watch it for MCLA_RUN_SECONDS
//   5  graphics only (title): create the Xenos GPU system on Vulkan, its
//      device and its presenter; nothing else
//   6  presentation (title): stage 5 with a window on SDL's offscreen video
//      driver, standing for the display. Attaching the presenter to it makes
//      the VK_KHR_display surface and the swapchain; the message loop then
//      runs for MCLA_RUN_SECONDS with a repaint requested every second. No
//      guest code, so the picture is whatever the presenter clears to
//   7  the game with graphics (title): the window and graphics system of
//      stage 6 handed to the runtime, then stage 4's run with the message
//      loop on the main thread

#include "generated/default/mcla_init.h"

#include <signal.h>
#include <ucontext.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <memory>
#include <string>
#include <thread>
#include <vector>

#include <rex/cvar.h>
#include <rex/input/device_assignment.h>
#include <rex/input/input_system.h>
#include <rex/input/nop/nop_input_driver.h>
#include <rex/kernel/crt/heap.h>
#include <rex/kernel/init.h>
#include <rex/logging.h>
#include <rex/memory/utils.h>
#include <rex/runtime.h>
#include <rex/system/gpu_plugin.h>
#include <rex/ui/presenter.h>
#include <rex/ui/window.h>
#include <rex/ui/windowed_app_context_sdl.h>
#include <rex/system/kernel_state.h>
#include <rex/system/util/object_table.h>
#include <rex/system/xthread.h>
#include <rex/thread.h>

#include <pthread.h>

// FreeBSD's thread id call; its header is not in every SDK.
extern "C" int pthread_getthreadid_np(void);

namespace rex::arch {
uint64_t Ps5FaultCount();
}
extern const char* g_mcla_settings_path;  // src/settings_menu.cpp
void MclaWaitForSaves();                   // src/save_wait.cpp
void MclaMigrateAntiAliasing();            // src/perf_options.cpp
void MclaApplyGraphicsFixDefaults(bool vulkan);  // src/perf_options.cpp
// src/shader_prepare.cpp
void MclaShaderStorageBeforeLaunch(rex::Runtime* runtime, rex::ui::Window* window,
                                   bool then_play);
void MclaShaderStorageAfterPreload(rex::Runtime* runtime);
namespace rex::ui::vulkan {
uint64_t Ps5PresentCount();
}
namespace rex::graphics {
uint64_t SharedMemoryUploadedBytes();
void SharedMemoryCounters(uint64_t out[10]);
namespace vulkan {
void SubmissionCounters(uint64_t out[4]);
uint64_t DrawCounter();
uint64_t HostDrawCounter();
}
}

// As a title (-DMCLA_TITLE) the log goes over a TCP connection from the PC; as
// a payload g_mcla_log_fd is standard output, the loader socket.
#include "title_log.h"
#include "log_fd_sink.h"
#ifdef MCLA_TITLE
#include "ps5_audio.h"
#include "ps5_pad_input.h"
#endif

// Defined in src/audio_fallback.cpp: a platform's own audio output, tried
// before SDL.
extern rex::audio::AudioDriver* (*g_mcla_platform_audio_driver)(rex::memory::Memory* memory,
                                                                rex::thread::Semaphore* semaphore);

#ifndef MCLA_STAGE
#define MCLA_STAGE 4
#endif
#ifndef MCLA_RUN_SECONDS
#define MCLA_RUN_SECONDS 20
#endif
#ifndef MCLA_PS5_ROOT
#define MCLA_PS5_ROOT "/data/mcla"
#endif

REXCVAR_DECLARE(uint32_t, rexcrt_heap_size_mb);

std::unique_ptr<rex::system::IAudioSystem> CreateMclaAudioSystem(
    rex::runtime::FunctionDispatcher* function_dispatcher);

// The console's shell draws its launch splash over a title until the title
// asks for it to be hidden: frames presented before that are flipped but not
// seen. A plain import, and only in a title: the title converter leaves a
// weak import unbound (the call was silently skipped when it was one).
#ifdef MCLA_TITLE
extern "C" int sceSystemServiceHideSplashScreen(void);
// Asks the shell to close the title (with the path "exit"). A title may not
// end itself with the exit system call: that is refused with SIGSYS.
extern "C" int sceSystemServiceLoadExec(const char* path, char* const argv[]);
#endif

// The Xenos GPU plugin's factory. On the other platforms the plugin is a
// shared library found by name at run time; here it is linked in.
extern "C" rex::system::IGraphicsSystem* rex_gpu_create(uint32_t abi_version,
                                                        const rex::system::GpuCreateInfo* info);

// --- Early crash reporter -------------------------------------------------------
//
// Installed from a constructor that runs ahead of the runtime's static
// objects. Prints the signal, fault address and instruction pointer straight
// to the socket and exits; it never returns into the context. The runtime's
// own fault handler takes over SIGSEGV/SIGBUS/SIGILL later and hands a fault
// nobody claims back to this one.

namespace {

void EarlyWrite(const char* text) {
  (void)!write(g_mcla_log_fd,text, std::strlen(text));
}

void EarlyHex(const char* label, uint64_t value) {
  char buffer[96];
  static const char digits[] = "0123456789abcdef";
  size_t n = 0;
  while (*label) buffer[n++] = *label++;
  buffer[n++] = '0';
  buffer[n++] = 'x';
  for (int shift = 60; shift >= 0; shift -= 4) buffer[n++] = digits[(value >> shift) & 0xF];
  buffer[n++] = '\n';
  (void)!write(g_mcla_log_fd,buffer, n);
}

int EarlyAnchor() { return 0; }

void EarlyCrash(int signal_number, siginfo_t* info, void* context) {
  EarlyWrite("CRASH\n");
  EarlyHex("  signal ", static_cast<uint64_t>(signal_number));
  EarlyHex("  fault address ", reinterpret_cast<uint64_t>(info->si_addr));
  // The machine context is 0x40 bytes into the signal context on firmware
  // 13.42, whatever the SDK's ucontext_t says.
  auto* machine = reinterpret_cast<mcontext_t*>(static_cast<uint8_t*>(context) + 0x40);
  const uint64_t anchor = reinterpret_cast<uint64_t>(&EarlyAnchor);
  EarlyHex("  instruction pointer ", static_cast<uint64_t>(machine->mc_rip));
  EarlyHex("  address of EarlyAnchor ", anchor);
  EarlyHex("  rsp ", static_cast<uint64_t>(machine->mc_rsp));
  // Return addresses on the stack, for a rough backtrace. The image is larger
  // than the probes', so accept anything within 512 MiB of this function.
  const uint64_t* stack = reinterpret_cast<const uint64_t*>(machine->mc_rsp);
  int printed = 0;
  for (int i = 0; i < 1024 && printed < 16; ++i) {
    const uint64_t word = stack[i];
    // A title is loaded at 0x400000, below the range: do not let the lower bound wrap.
    const uint64_t low = anchor > 0x20000000 ? anchor - 0x20000000 : 0x1000;
    if (word > low && word < anchor + 0x20000000) {
      EarlyHex("  stack code pointer ", word);
      ++printed;
    }
  }
  _exit(100 + signal_number);
}

void ReportExit() {
  EarlyWrite("EXIT: the process is leaving through exit()\n");
}

__attribute__((constructor(101))) void InstallEarlyCrashReporter() {
  MclaTitleLogConnect();
  atexit(ReportExit);
  EarlyWrite("early constructor: installing the crash reporter\n");
  struct sigaction action;
  std::memset(&action, 0, sizeof action);
  action.sa_sigaction = EarlyCrash;
  action.sa_flags = SA_SIGINFO;
  sigemptyset(&action.sa_mask);
  // Beyond the faults: anything else catchable that would end the process
  // without a word (a refused system call arrives as SIGSYS).
  for (int signal_number : {SIGSEGV, SIGBUS, SIGILL, SIGABRT, SIGFPE, SIGSYS, SIGTRAP, SIGTERM,
                            SIGHUP, SIGQUIT, SIGPIPE, SIGXFSZ}) {
    sigaction(signal_number, &action, nullptr);
  }
}

// --- Thread dump -------------------------------------------------------------------
//
// When the game stalls there is no debugger to ask why. This signals each of
// the runtime's threads in turn; the handler prints where that thread is
// executing and the code addresses on its stack, and returns without touching
// the context. Addresses are symbolised on the PC against the linked ELF.

constexpr int kDumpSignal = SIGXCPU;

// Set while the sampling profiler runs: the handler then writes one compact
// line per sample instead of the readable dump.
std::atomic<bool> g_profile_sampling{false};

size_t AppendHex(char* buffer, size_t n, uint64_t value) {
  static const char digits[] = "0123456789abcdef";
  int shift = 60;
  while (shift > 0 && ((value >> shift) & 0xF) == 0) shift -= 4;
  for (; shift >= 0; shift -= 4) buffer[n++] = digits[(value >> shift) & 0xF];
  return n;
}

void DumpHandler(int, siginfo_t*, void* context) {
  auto* machine = reinterpret_cast<mcontext_t*>(static_cast<uint8_t*>(context) + 0x40);
  const uint64_t anchor = reinterpret_cast<uint64_t>(&EarlyAnchor);
  const uint64_t low = anchor > 0x20000000 ? anchor - 0x20000000 : 0x1000;
  if (g_profile_sampling.load(std::memory_order_relaxed)) {
    // "S <thread> <pc> <code address on the stack> ..." in one write.
    char line[256];
    size_t n = 0;
    line[n++] = 'S';
    line[n++] = ' ';
    n = AppendHex(line, n, static_cast<uint64_t>(pthread_getthreadid_np()));
    line[n++] = ' ';
    n = AppendHex(line, n, static_cast<uint64_t>(machine->mc_rip));
    const uint64_t* words = reinterpret_cast<const uint64_t*>(machine->mc_rsp);
    int found = 0;
    for (int i = 0; i < 512 && found < 8; ++i) {
      const uint64_t word = words[i];
      if (word > low && word < anchor + 0x20000000) {
        line[n++] = ' ';
        n = AppendHex(line, n, word);
        ++found;
      }
    }
    line[n++] = '\n';
    (void)!write(g_mcla_log_fd, line, n);
    return;
  }
  EarlyHex("  tid ", static_cast<uint64_t>(pthread_getthreadid_np()));
  EarlyHex("  pc ", static_cast<uint64_t>(machine->mc_rip));
  const uint64_t* stack = reinterpret_cast<const uint64_t*>(machine->mc_rsp);
  int printed = 0;
  for (int i = 0; i < 1024 && printed < 14; ++i) {
    const uint64_t word = stack[i];
    if (word > low && word < anchor + 0x20000000) {
      EarlyHex("  stack ", word);
      ++printed;
    }
  }
}

void InstallDumpHandler() {
  struct sigaction action;
  std::memset(&action, 0, sizeof action);
  action.sa_sigaction = DumpHandler;
  action.sa_flags = SA_SIGINFO | SA_RESTART;
  sigemptyset(&action.sa_mask);
  sigaction(kDumpSignal, &action, nullptr);
}

void Line(const char* format, ...);

void DumpRuntimeThreads(rex::system::KernelState* kernel_state) {
  auto threads = kernel_state->object_table()->GetObjectsByType<rex::system::XThread>();
  Line("THREAD DUMP: %d runtime threads, code anchor %p", static_cast<int>(threads.size()),
       reinterpret_cast<void*>(&EarlyAnchor));
  for (auto& thread : threads) {
    if (!thread || !thread->thread()) continue;
    Line(" thread '%s' id %u%s", thread->name().c_str(), static_cast<unsigned>(thread->thread_id()),
         thread->is_guest_thread() ? " (guest)" : "");
    pthread_kill(reinterpret_cast<pthread_t>(thread->thread()->native_handle()), kDumpSignal);
    std::this_thread::sleep_for(std::chrono::milliseconds(150));
  }
  Line("THREAD DUMP ends");
}

// A sampling profiler out of the same signal: every runtime thread, `hertz`
// times a second for `seconds`, one line per sample. ps5/profile_report.py
// turns the lines into per-thread function counts on the PC.
// host_only: just the runtime's own threads (the GPU command thread among
// them), which can then be sampled much more often.
void ProfileRuntimeThreads(rex::system::KernelState* kernel_state, int seconds, int hertz,
                           bool host_only = false) {
  Line("PROFILE begins: %d s at %d Hz, code anchor %p", seconds, hertz,
       reinterpret_cast<void*>(&EarlyAnchor));
  g_profile_sampling.store(true);
  const auto period = std::chrono::microseconds(1000000 / hertz);
  for (int sample = 0; sample < seconds * hertz; ++sample) {
    // Re-read the list now and then: the game creates and ends threads.
    static std::vector<rex::system::object_ref<rex::system::XThread>> threads;
    if (sample % hertz == 0) {
      threads = kernel_state->object_table()->GetObjectsByType<rex::system::XThread>();
    }
    for (auto& thread : threads) {
      if (thread && thread->thread() && !(host_only && thread->is_guest_thread())) {
        pthread_kill(reinterpret_cast<pthread_t>(thread->thread()->native_handle()), kDumpSignal);
      }
    }
    std::this_thread::sleep_for(period);
  }
  std::this_thread::sleep_for(std::chrono::milliseconds(200));
  g_profile_sampling.store(false);
  Line("PROFILE ends");
}

void Line(const char* format, ...) {
  char text[512];
  va_list args;
  va_start(args, format);
  std::vsnprintf(text, sizeof text - 1, format, args);
  va_end(args);
  const size_t length = std::strlen(text);
  text[length] = '\n';
  (void)!write(g_mcla_log_fd, text, length + 1);
}

// Printed before an operation, so the last "NEXT" line names what was running
// if the output stops.
#define NEXT(...) Line("NEXT " __VA_ARGS__)

int Finish(const char* what, int code) {
  Line("mcla-ps5 stops: %s", what);
  rex::FlushLogging();
  std::fflush(stdout);
  // No teardown: guest threads may be running, and the runtime's shutdown
  // path is not something to try for the first time on the console.
  _exit(code);
}

}  // namespace

int main() {
  setvbuf(stdout, nullptr, _IONBF, 0);
  Line("mcla-ps5 starts, pid %d, stage %d", getpid(), MCLA_STAGE);
#ifndef MCLA_PLAY
  alarm(MCLA_RUN_SECONDS + 120);
#endif

  const std::filesystem::path root = MCLA_PS5_ROOT;
  const std::filesystem::path game_root = root / "game";
  const std::filesystem::path user_root = root / "user";
  const std::filesystem::path cache_root = root / "cache";

  NEXT("check the game folder %s", game_root.c_str());
  std::error_code ec;
  if (!std::filesystem::is_regular_file(game_root / "default.xex", ec)) {
    return Finish("default.xex is not in the game folder", 2);
  }
  std::filesystem::create_directories(user_root, ec);
  std::filesystem::create_directories(cache_root, ec);

  NEXT("initialise cvars and logging (standard output)");
  char program[] = "mcla";
  char* arguments[] = {program, nullptr};
  rex::cvar::Init(1, arguments);
  rex::InitLoggingEarly();
  // The runtime's log goes to the same place as this file's own lines: the
  // loader socket in a payload, the PC's connection in a title (where
  // standard output cannot be used at all, see ps5/title_log.h).
  rex::LogConfig log_config;
  log_config.log_to_console = false;
  log_config.extra_sinks.push_back(std::make_shared<MclaFdSink>(g_mcla_log_fd));
#ifdef MCLA_LOG_LEVEL
  log_config.default_level = spdlog::level::from_str(MCLA_LOG_LEVEL);
#endif
  log_config.flush_level = spdlog::level::trace;
  rex::InitLogging(log_config);

#if MCLA_STAGE == 5
  // Graphics only: the Xenos GPU system on its Vulkan backend, created from
  // the statically linked plugin, and its provider (instance, device) and
  // presenter. No window, no runtime, no guest code.
  {
    NEXT("create the Xenos graphics system (Vulkan backend)");
    rex::system::GpuCreateInfo create_info;
    create_info.struct_size = sizeof create_info;
    create_info.backend = "vulkan";
    std::unique_ptr<rex::system::IGraphicsSystem> graphics(
        rex_gpu_create(rex::system::kGpuPluginAbiVersion, &create_info));
    if (!graphics) {
      return Finish("the GPU plugin returned no graphics system", 7);
    }
    NEXT("SetupPresentation: Vulkan instance, device and presenter, without a window");
    const auto graphics_status = graphics->SetupPresentation(nullptr);
    if (XFAILED(graphics_status)) {
      Line("SetupPresentation failed: %08X", static_cast<unsigned>(graphics_status));
      return Finish("graphics setup failed", 8);
    }
    Line("PASS Vulkan device and presenter created");
    return Finish("stage 5 complete", 0);
  }
#endif

#if MCLA_STAGE == 6
  {
    NEXT("SDL application context on the offscreen video driver");
    rex::cvar::SetFlagByName("video_driver", "offscreen");
    rex::ui::SDLWindowedAppContext app_context;
    if (!app_context.Initialize()) {
      return Finish("the SDL application context did not initialise", 9);
    }

    NEXT("create the Xenos graphics system (Vulkan backend)");
    rex::system::GpuCreateInfo create_info;
    create_info.struct_size = sizeof create_info;
    create_info.backend = "vulkan";
    std::unique_ptr<rex::system::IGraphicsSystem> graphics(
        rex_gpu_create(rex::system::kGpuPluginAbiVersion, &create_info));
    if (!graphics) {
      return Finish("the GPU plugin returned no graphics system", 7);
    }
    NEXT("SetupPresentation with the application context");
    const auto graphics_status = graphics->SetupPresentation(&app_context);
    if (XFAILED(graphics_status) || !graphics->presenter()) {
      Line("SetupPresentation failed: %08X", static_cast<unsigned>(graphics_status));
      return Finish("graphics setup failed", 8);
    }

    NEXT("create a 1280x720 window");
    auto window = rex::ui::Window::Create(app_context, "mcla", 1280, 720);
    if (!window) {
      return Finish("no window", 10);
    }
    NEXT("open the window");
    if (!window->Open()) {
      return Finish("the window did not open", 11);
    }
    NEXT("attach the presenter to the window (display surface and swapchain)");
    window->SetPresenter(graphics->presenter());
#ifdef MCLA_TITLE
    {
      NEXT("hide the console's launch splash");
      Line("sceSystemServiceHideSplashScreen returned 0x%08X",
           static_cast<unsigned>(sceSystemServiceHideSplashScreen()));
    }
#endif

    NEXT("run the message loop for %d s, requesting a repaint every second", MCLA_RUN_SECONDS);
    std::thread ticker([&app_context, &window]() {
      for (int second = 1; second <= MCLA_RUN_SECONDS; ++second) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
        Line("alive: %d s", second);
        app_context.CallInUIThread([&window]() { window->RequestPaint(); });
      }
      app_context.RequestDeferredQuit();
    });
    app_context.RunMainMessageLoop();
    ticker.join();
    Line("PASS message loop ended normally");
    return Finish("stage 6 complete", 0);
  }
#endif

#if MCLA_STAGE >= 7
  // Presentation first, as the desktop host does: the graphics system has to
  // know it will present before the runtime wires it to the guest.
  NEXT("SDL application context on the offscreen video driver");
#ifdef MCLA_TITLE
  // The Vulkan driver reports on standard error (failures, and every 10 s
  // where its submissions' time went), which in a title goes nowhere. Point
  // the C library's stderr at the title log.
  if (FILE* log_stream = fdopen(g_mcla_log_fd, "w")) {
    setvbuf(log_stream, nullptr, _IOLBF, 0);
    stderr = log_stream;
  }
#endif
  // What the in-game settings menu saved. Loaded before the host's own
  // settings below, which therefore win.
  g_mcla_settings_path = "/data/mcla/mcla.toml";
  try {
    rex::cvar::LoadConfig(g_mcla_settings_path);
    Line("settings: %s read, intro = %s", g_mcla_settings_path,
         rex::cvar::GetFlagByName("mcla_intro").c_str());
  } catch (const std::exception& e) {
    Line("settings: %s not read: %s", g_mcla_settings_path, e.what());
  }
  rex::cvar::SetFlagByName("video_driver", "offscreen");
  // The SDL input driver looks for an optional controller mapping file by a
  // relative path. In a title that lookup fails with an error other than "not
  // found", which std::filesystem::exists turns into an exception nobody
  // catches. There is no such file here; do not look.
  rex::cvar::SetFlagByName("hid_mappings_file", "");
  // Pacing is the frame limiter's job, as on the desktop (MclaApp::
  // ConfigureFrameTiming): with the emulated console vsync also on, a frame
  // that misses a display interval waits for the next one.
  rex::cvar::SetFlagByName("vsync", "false");
  // A protection change costs 26 us on the console whatever its size (arena
  // step 13), and the GPU emulation was spending a quarter of its thread on
  // them: watch guest physical memory in 64 KiB units, not 16 KiB host pages.
#ifndef MCLA_WATCH_GRANULARITY
#define MCLA_WATCH_GRANULARITY 0
#endif
#define MCLA_STRINGIZE_(x) #x
#define MCLA_STRINGIZE(x) MCLA_STRINGIZE_(x)
  rex::cvar::SetFlagByName("physical_watch_granularity", MCLA_STRINGIZE(MCLA_WATCH_GRANULARITY));
  // And make re-watching as coarse as invalidation already is: requests for
  // guest memory are widened to 64 KiB chunks, so a fault is followed by one
  // protection change and not one per draw that uses the area.
#ifndef MCLA_REQUEST_GRANULARITY_LOG2
#define MCLA_REQUEST_GRANULARITY_LOG2 16
#endif
  rex::cvar::SetFlagByName("shared_memory_request_granularity_log2",
                           MCLA_STRINGIZE(MCLA_REQUEST_GRANULARITY_LOG2));
  // Memory the game rewrites every frame (dynamic vertex data) is not worth
  // watching at all here: after a few write faults in a second a page is hot
  // for ten seconds, not watched and simply uploaded when a draw uses it. The
  // watch unit is the host page again so that a hot page is exactly that.
#ifndef MCLA_HOT_PAGE_FAULTS
#define MCLA_HOT_PAGE_FAULTS 4
#endif
  rex::cvar::SetFlagByName("shared_memory_hot_page_faults", MCLA_STRINGIZE(MCLA_HOT_PAGE_FAULTS));
  // From the tuning runs (docs/ps5-port-plan.md): a hot page has to fault its
  // way back to hot each time its period ends, so the period is long; a write
  // fault invalidates 16 pages around it (256 KiB, what 64 pages are on a PC).
  rex::cvar::SetFlagByName("shared_memory_hot_page_ms", "10000");
  rex::cvar::SetFlagByName("shared_memory_invalidation_pages_log2", "4");
  // The runtime by default forgets at the end of every frame which pages are
  // already in the GPU buffer, and copies all that are in use again: over
  // 1 GiB/s here, against about 80 MiB/s with the write watches trusted.
#ifndef MCLA_CLEAR_PAGE_STATE
#define MCLA_CLEAR_PAGE_STATE false
#endif
  rex::cvar::SetFlagByName("clear_memory_page_state", MCLA_STRINGIZE(MCLA_CLEAR_PAGE_STATE));
  // The runtime submits its command buffer to the driver each time the guest's
  // primary buffer runs dry, three or four times a frame, and a submission is
  // a blocking call into the console's driver: about 0.1 ms each when
  // driving but 1.5 ms in the zoomed-out map, a fifth of the GPU command
  // thread there. Without this it submits when the frame ends (or when it
  // has to).
#ifndef MCLA_SUBMIT_ON_BUFFER_END
#define MCLA_SUBMIT_ON_BUFFER_END false
#endif
  rex::cvar::SetFlagByName("vulkan_submit_on_primary_buffer_end",
                           MCLA_STRINGIZE(MCLA_SUBMIT_ON_BUFFER_END));
  // An EDRAM of 4,096 tiles instead of the console's 2,048 (the SDK's
  // edram_tiles), so that the scene with 2x MSAA fits in one tile and is drawn
  // once instead of twice (src/render_perf.cpp, mcla_single_tile; RADV binds
  // the larger buffer whole). Untested on the console. As a default it gives
  // way to an edram_tiles line in /data/mcla/mcla.toml; build with
  // -DMCLA_EDRAM_TILES=2048 for the console's size. Read when the GPU starts,
  // so not part of the tuning below.
#ifndef MCLA_EDRAM_TILES
#define MCLA_EDRAM_TILES 4096
#endif
  rex::cvar::SetDefaultValue("edram_tiles", MCLA_STRINGIZE(MCLA_EDRAM_TILES));
  Line("settings: edram_tiles = %s", rex::cvar::GetFlagByName("edram_tiles").c_str());
  // Anisotropic filtering at 16x instead of the SDK's 4x, as on PC (src/mcla_app.cpp,
  // ApplyPcDefaults): the only level never below what the game asks for. Untested on
  // the console; an anisotropic_override line in /data/mcla/mcla.toml wins.
  rex::cvar::SetDefaultValue("anisotropic_override", "5");
  Line("settings: anisotropic_override = %s", rex::cvar::GetFlagByName("anisotropic_override").c_str());
  // The shader pack's import (src/shader_prepare.cpp): at every start, whatever of the pack the
  // storage lacks is rebuilt from the game's files and added before the storage loads
  // (mcla_shader_pack_auto, on by default; there is no launcher to prepare apart). make_ps5.sh
  // puts the pack here. Untested on the console.
  rex::cvar::SetDefaultValue("mcla_shader_pack", (root / "shaderpack" / "545407F8.shaderpack").string());
  // An older mcla_msaa = false in the settings file still means no anti-aliasing.
  MclaMigrateAntiAliasing();
  // The custom vinyls' readback and the Vulkan depth conversion (src/perf_options.cpp): defaults of SDK options, as on the PC.
  // Untested on the console (the PC's Vulkan is where they were measured).
  MclaApplyGraphicsFixDefaults(true);
  // FSR 3.1 (rexglue-temporal-aa.patch) and its frame generation
  // (rexglue-frame-generation.patch) are untested on the console: the Vulkan
  // device gets the features they use only when the game starts with one of
  // them chosen (mcla_anti_aliasing = fsr or frame_generation = fsr), so that
  // everyone else's device stays as it was. Chosen during play (the pause menu
  // offers both), it takes effect at the next start.
  const bool fsr_at_start = rex::cvar::GetFlagByName("mcla_anti_aliasing") == "fsr" ||
                            rex::cvar::GetFlagByName("frame_generation") == "fsr";
  rex::cvar::SetFlagByName("temporal_aa_device_features", fsr_at_start ? "true" : "false");
  Line("settings: mcla_anti_aliasing = %s, frame_generation = %s (FSR's device features %s)",
       rex::cvar::GetFlagByName("mcla_anti_aliasing").c_str(),
       rex::cvar::GetFlagByName("frame_generation").c_str(), fsr_at_start ? "on" : "off");
  // The GPU's latency reducer (rexglue-low-latency.patch: AMD Anti-Lag 2, VK_AMD_anti_lag) is
  // untested on the console too: the device is asked for the extension only when the game starts
  // with low_latency on or boost, or with frame generation chosen (which turns it on), so that
  // everyone else's device stays as it was.
  const std::string low_latency_choice = rex::cvar::GetFlagByName("low_latency");
  const bool low_latency_at_start = low_latency_choice == "on" || low_latency_choice == "boost" ||
                                    rex::cvar::GetFlagByName("frame_generation") == "fsr";
  rex::cvar::SetFlagByName("low_latency_device_extensions",
                           low_latency_at_start ? "true" : "false");
  Line("settings: low_latency = %s (the device's low latency extensions %s)",
       low_latency_choice.c_str(), low_latency_at_start ? "on" : "off");
  rex::ui::SDLWindowedAppContext app_context;
  if (!app_context.Initialize()) {
    return Finish("the SDL application context did not initialise", 9);
  }
  NEXT("create the Xenos graphics system (Vulkan backend)");
  rex::system::GpuCreateInfo gpu_create_info;
  gpu_create_info.struct_size = sizeof gpu_create_info;
  gpu_create_info.backend = "vulkan";
  std::unique_ptr<rex::system::IGraphicsSystem> graphics(
      rex_gpu_create(rex::system::kGpuPluginAbiVersion, &gpu_create_info));
  if (!graphics) {
    return Finish("the GPU plugin returned no graphics system", 7);
  }
  NEXT("SetupPresentation with the application context");
  if (XFAILED(graphics->SetupPresentation(&app_context)) || !graphics->presenter()) {
    return Finish("graphics setup failed", 8);
  }
  NEXT("create and open the window, attach the presenter");
  auto window = rex::ui::Window::Create(app_context, "mcla", 1280, 720);
  if (!window || !window->Open()) {
    return Finish("no window", 10);
  }
  window->SetPresenter(graphics->presenter());
#ifdef MCLA_TITLE
  {
    NEXT("hide the console's launch splash");
    Line("sceSystemServiceHideSplashScreen returned 0x%08X",
         static_cast<unsigned>(sceSystemServiceHideSplashScreen()));
  }
#endif
#endif

  NEXT("construct rex::Runtime");
  auto runtime = std::make_unique<rex::Runtime>(game_root, user_root, std::filesystem::path(),
                                                cache_root, std::filesystem::path());
#if MCLA_STAGE >= 7
  runtime->set_app_context(&app_context);
  runtime->set_display_window(window.get());
#endif

#ifdef MCLA_TITLE
  // Sound through the console's audio library (ps5_audio.h); if the port does
  // not open, the game's own fallback carries on to SDL and then to silence.
  g_mcla_platform_audio_driver = [](rex::memory::Memory* memory,
                                    rex::thread::Semaphore* semaphore) -> rex::audio::AudioDriver* {
    auto driver = std::make_unique<Ps5AudioDriver>(memory, semaphore);
    return driver->Initialize() ? driver.release() : nullptr;
  };
#endif
  rex::RuntimeConfig config;
  config.audio_factory = &CreateMclaAudioSystem;
  config.kernel_init = rex::kernel::InitializeKernel;
#if MCLA_STAGE >= 7
  config.graphics = std::move(graphics);
  // The game asks about controllers as soon as it has graphics, and the kernel
  // calls it uses assume an input system exists. The default one, as on the
  // desktop; whether it finds a controller on the console is P7.
#ifdef MCLA_TITLE
  // The console's own pad library (ps5_pad_input.h); SDL has no gamepad
  // backend here. If no controller can be opened, the stand-in driver keeps
  // an idle one present so the game does not wait for a controller forever.
  config.input_factory = [](bool) -> std::unique_ptr<rex::system::IInputSystem> {
    auto input = std::make_unique<rex::input::InputSystem>(nullptr);
    auto pad = std::make_unique<Ps5PadInputDriver>();
    if (pad->Setup() == rex::X_STATUS(0)) {
      input->AddDriver(std::move(pad));
    } else {
      input->AddDriver(std::make_unique<rex::input::nop::NopInputDriver>(nullptr, 0));
    }
    // Every pad is player one, as on the PC (src/mcla_app.cpp): a pad that
    // reconnects gets a new number and would otherwise become player two,
    // which is not signed in, so the game stops saving (issue #22).
    input->SetDeviceAssignment(std::make_unique<rex::input::SharedAssignment>());
    return input;
  };
#else
  config.input_factory = REX_INPUT_BACKEND(rex::input::CreateDefaultInputSystem);
#endif
#else
  // No graphics system and no input system: P5 and P7.
#endif

  rex::PPCImageInfo image = PPCImageConfig;
  NEXT("Runtime::Setup (guest memory, function table, kernel state, file systems)");
  auto status = runtime->Setup(image, std::move(config));
  if (XFAILED(status)) {
    Line("Runtime::Setup failed: %08X", static_cast<unsigned>(status));
    return Finish("setup failed", 3);
  }
  if (image.register_modules) {
    NEXT("register guest modules");
    image.register_modules(runtime->kernel_state());
  }
#if MCLA_STAGE >= 7
  if (runtime->input_system()) {
    static_cast<rex::input::InputSystem*>(runtime->input_system())->AttachWindow(window.get());
  }
#endif
  Line("PASS Runtime::Setup");
  if (MCLA_STAGE <= 1) return Finish("stage 1 complete", 0);

  NEXT("Runtime::LoadXexImage game:\\default.xex");
  status = runtime->LoadXexImage("game:\\default.xex");
  if (XFAILED(status)) {
    Line("LoadXexImage failed: %08X", static_cast<unsigned>(status));
    return Finish("XEX load failed", 4);
  }
  Line("PASS XEX image loaded, title id %08X",
       static_cast<unsigned>(runtime->kernel_state()->title_id()));
  if (MCLA_STAGE <= 2) return Finish("stage 2 complete", 0);

  if (image.rexcrt_heap) {
    NEXT("create the guest heap (%u MiB)", static_cast<unsigned>(REXCVAR_GET(rexcrt_heap_size_mb)));
    if (!rex::kernel::crt::InitHeap(REXCVAR_GET(rexcrt_heap_size_mb), runtime->memory())) {
      return Finish("guest heap creation failed", 5);
    }
  }
  runtime->file_system()->RegisterSymbolicLink("t:", "\\Device\\Harddisk0\\Partition1");

  NEXT("Runtime::PrepareModuleLaunch (suspended main guest thread)");
  auto main_thread = runtime->PrepareModuleLaunch();
  if (!main_thread) {
    return Finish("could not create the main guest thread", 6);
  }
  Line("PASS main guest thread created");
  if (MCLA_STAGE <= 3) return Finish("stage 3 complete", 0);

#if MCLA_STAGE >= 7
  if (runtime->graphics_system()) {
    NEXT("shader pack import (%s)", rex::cvar::GetFlagByName("mcla_shader_pack").c_str());
    MclaShaderStorageBeforeLaunch(runtime.get(), nullptr, /*then_play=*/true);
    NEXT("initialise shader storage under %s", cache_root.c_str());
    runtime->graphics_system()->InitializeShaderStorage(cache_root, runtime->kernel_state()->title_id(),
                                                        true);
    MclaShaderStorageAfterPreload(runtime.get());
  }
#endif

  NEXT("resume the main guest thread; guest code runs from here");
  main_thread->Resume();

#if MCLA_STAGE >= 7
  // The message loop needs this thread; a second one reports and ends the run.
  InstallDumpHandler();
  std::thread ticker([&app_context, &runtime]() {
    int next_profile_second = 15;
    for (int second = 1; second <= MCLA_RUN_SECONDS; ++second) {
      std::this_thread::sleep_for(std::chrono::seconds(1));
#ifdef MCLA_PLAY
      // A build for playing: none of the periodic diagnostics below (thread
      // dumps, counters, profiles), and no end to the run.
      --second;
      continue;
#endif
      if (second <= 30 || second % 30 == 0) Line("alive: %d s", second);
      // Every five seconds: how many protection changes and faults the
      // runtime made, the two costs the profile points at.
      if (second % 5 == 0) {
        static uint64_t last_protects = 0, last_faults = 0;
        const uint64_t protects = rex::memory::Ps5ProtectCallCount();
        const uint64_t faults = rex::arch::Ps5FaultCount();
        Line("STATS %d s: %llu protection changes/s, %llu faults/s", second,
             static_cast<unsigned long long>((protects - last_protects) / 5),
             static_cast<unsigned long long>((faults - last_faults) / 5));
#if MCLA_STAGE >= 7
        static uint64_t last_presents = 0, last_uploaded = 0;
        const uint64_t presents = rex::ui::vulkan::Ps5PresentCount();
        const uint64_t uploaded = rex::graphics::SharedMemoryUploadedBytes();
        Line("STATS %d s: %.1f presents/s, %.1f MiB/s copied to the GPU buffer", second,
             static_cast<double>(presents - last_presents) / 5.0,
             static_cast<double>(uploaded - last_uploaded) / 5.0 / 1048576.0);
        static uint64_t last_counters[10] = {};
        uint64_t counters[10] = {};
        rex::graphics::SharedMemoryCounters(counters);
        double rate[10];
        for (int i = 0; i < 10; ++i) {
          rate[i] = static_cast<double>(counters[i] - last_counters[i]) / 5.0;
          last_counters[i] = counters[i];
        }
        const double mib = 1048576.0;
        Line("STATS %d s: of that %.1f MiB/s hot pages, for %.1f MiB/s the draws asked for; "
             "%.0f requests/s; %.0f pages/s turned hot",
             second, rate[0] / mib, rate[1] / mib, rate[2], rate[9]);
        Line("STATS %d s: tracked pages uploaded, MiB/s: first time %.1f, after a write fault "
             "%.1f, after an explicit invalidation %.1f, with no invalidation %.1f; invalidated "
             "by faults %.1f, explicitly %.1f",
             second, rate[3] / mib, rate[4] / mib, rate[5] / mib, rate[6] / mib, rate[7] / mib,
             rate[8] / mib);
        last_presents = presents;
        last_uploaded = uploaded;
#endif
        // And who asked for the protection changes.
        static uint64_t last_site[rex::memory::kPs5ProtectSiteCount] = {};
        uint64_t per_second[rex::memory::kPs5ProtectSiteCount];
        for (int site = 0; site < rex::memory::kPs5ProtectSiteCount; ++site) {
          const uint64_t count = rex::memory::Ps5ProtectCallCount(site);
          per_second[site] = (count - last_site[site]) / 5;
          last_site[site] = count;
        }
        Line("STATS %d s: by caller/s: watch enable %llu, watch trigger %llu, host page sync %llu, "
             "stale recovery %llu, other %llu",
             second, static_cast<unsigned long long>(per_second[1]),
             static_cast<unsigned long long>(per_second[2]),
             static_cast<unsigned long long>(per_second[3]),
             static_cast<unsigned long long>(per_second[4]),
             static_cast<unsigned long long>(per_second[0]));
        last_protects = protects;
        last_faults = faults;
      }
      // Twice, a few seconds apart: a thread at the same place both times is
      // stuck there, one that has moved is running.
      if (second == 4 || second == 8) {
        DumpRuntimeThreads(runtime->kernel_state());
      }
#ifdef MCLA_TITLE
      // A profile on request from the controller (L3 + R3 + touchpad), at most
      // one every 40 s: whoever is playing picks the moment.
      if (second >= next_profile_second &&
          g_mcla_profile_request.exchange(false, std::memory_order_relaxed)) {
        Line("PROFILE requested from the controller at %d s", second);
        DumpRuntimeThreads(runtime->kernel_state());
        ProfileRuntimeThreads(runtime->kernel_state(), 20, 25);
        next_profile_second = second + 40;
        g_mcla_profile_request.store(false, std::memory_order_relaxed);
      }
#endif
#ifdef MCLA_TUNE_FROM
      // Tuning run: from this second on, a different combination of the two
      // write-tracking settings every 30 s, each announced, so that one drive
      // compares them (the STATS lines carry the presents and the copy volume
      // for each). The settings are read on every request, so they can change
      // while the game runs.
      {
        struct Combination {
          const char* request_log2;
          const char* hot_faults;
          const char* invalidation_pages_log2;
          const char* hot_ms;
          // clear_memory_page_state: forget at the end of every frame which
          // pages are already in the GPU buffer, so all in use are copied again.
          const char* clear_each_frame;
        };
        static const Combination combinations[] = {
            {"16", "4", "4", "10000", "true"},  {"16", "4", "4", "10000", "false"},
            {"18", "4", "6", "10000", "false"}, {"0", "4", "2", "10000", "false"},
            {"16", "4", "4", "10000", "true"},  {"16", "4", "4", "10000", "false"},
        };
        const int combination_count = static_cast<int>(sizeof combinations / sizeof combinations[0]);
        if (second >= MCLA_TUNE_FROM && (second - MCLA_TUNE_FROM) % 30 == 0) {
          const Combination& now = combinations[((second - MCLA_TUNE_FROM) / 30) % combination_count];
          rex::cvar::SetFlagByName("shared_memory_request_granularity_log2", now.request_log2);
          rex::cvar::SetFlagByName("shared_memory_hot_page_faults", now.hot_faults);
          rex::cvar::SetFlagByName("shared_memory_invalidation_pages_log2",
                                   now.invalidation_pages_log2);
          rex::cvar::SetFlagByName("shared_memory_hot_page_ms", now.hot_ms);
          rex::cvar::SetFlagByName("clear_memory_page_state", now.clear_each_frame);
          Line("TUNE %d s: request chunk 2^%s bytes, hot page after %s faults, a fault "
               "invalidates 2^%s pages, hot for %s ms, page state cleared each frame: %s",
               second, now.request_log2, now.hot_faults, now.invalidation_pages_log2, now.hot_ms,
               now.clear_each_frame);
        }
      }
#endif
#ifdef MCLA_PROFILE_DIPS
#ifndef MCLA_PROFILE_DIPS_FROM
#define MCLA_PROFILE_DIPS_FROM 45
#endif
      // Presents in every second, and a short profile of the moment whenever
      // they fall below MCLA_PROFILE_DIPS: at most four in a run, at least
      // 30 s apart, none in the first MCLA_PROFILE_DIPS_FROM seconds (45 unless
      // set: start-up and loading).
      {
        static uint64_t dip_last_presents = 0;
        static int dip_profiles = 0, dip_last_second = 0;
        const uint64_t dip_presents = rex::ui::vulkan::Ps5PresentCount();
        const unsigned in_second = static_cast<unsigned>(dip_presents - dip_last_presents);
        dip_last_presents = dip_presents;
        static uint64_t dip_last_submission[4] = {};
        uint64_t submission[4] = {};
        rex::graphics::vulkan::SubmissionCounters(submission);
        static uint64_t dip_last_draws = 0;
        const uint64_t dip_draws = rex::graphics::vulkan::DrawCounter();
        static uint64_t dip_last_host_draws = 0;
        const uint64_t dip_host_draws = rex::graphics::vulkan::HostDrawCounter();
        Line("FPS %d s: %u; %llu draws, %llu to the host; %llu submits taking %llu ms, %llu fence "
             "waits taking %llu ms",
             second, in_second, static_cast<unsigned long long>(dip_draws - dip_last_draws),
             static_cast<unsigned long long>(dip_host_draws - dip_last_host_draws),
             static_cast<unsigned long long>(submission[0] - dip_last_submission[0]),
             static_cast<unsigned long long>((submission[1] - dip_last_submission[1]) / 1000),
             static_cast<unsigned long long>(submission[2] - dip_last_submission[2]),
             static_cast<unsigned long long>((submission[3] - dip_last_submission[3]) / 1000));
        for (int i = 0; i < 4; ++i) {
          dip_last_submission[i] = submission[i];
        }
        dip_last_draws = dip_draws;
        dip_last_host_draws = dip_host_draws;
        if (second > MCLA_PROFILE_DIPS_FROM && in_second < MCLA_PROFILE_DIPS && dip_profiles < 4 &&
            second - dip_last_second >= 30) {
          ++dip_profiles;
          Line("DIP %d s: %u presents in the last second, profiling the host threads for 5 s", second, in_second);
          ProfileRuntimeThreads(runtime->kernel_state(), 5, 200, true);
          dip_last_second = second;
          dip_last_presents = rex::ui::vulkan::Ps5PresentCount();
        }
      }
#endif
#ifdef MCLA_PROFILE_AT
      // One profile while the game is being played (the time is chosen at
      // build time and told to whoever holds the controller).
      if (second == MCLA_PROFILE_AT) {
        DumpRuntimeThreads(runtime->kernel_state());
        ProfileRuntimeThreads(runtime->kernel_state(), 20, 25);
      }
#endif
    }
    Finish("run time reached", 0);
  });
  app_context.RunMainMessageLoop();
  // QUIT GAME ends the message loop. In a play build the ticker never ends,
  // so waiting for it left the picture frozen while the game ran on behind it;
  // end the process here instead.
  ticker.detach();
#ifdef MCLA_TITLE
  // Leave as a title does: the shell closes it and returns to the home screen.
  // The process idles until then; if the request is refused, fall through.
  // The system closes it at once, so a career save being written is let
  // finish first (the game's threads still run here).
  MclaWaitForSaves();
  Line("mcla-ps5 stops: the message loop ended; asking the system to close the title");
  rex::FlushLogging();
  const int result = sceSystemServiceLoadExec("exit", nullptr);
  Line("sceSystemServiceLoadExec(\"exit\") returned 0x%08X", static_cast<unsigned>(result));
  if (result == 0) {
    for (;;) {
      std::this_thread::sleep_for(std::chrono::seconds(1));
    }
  }
#endif
  return Finish("the message loop ended", 0);
#else
  for (int second = 1; second <= MCLA_RUN_SECONDS; ++second) {
    std::this_thread::sleep_for(std::chrono::seconds(1));
    Line("alive: %d s", second);
  }
  return Finish("run time reached", 0);
#endif
}
