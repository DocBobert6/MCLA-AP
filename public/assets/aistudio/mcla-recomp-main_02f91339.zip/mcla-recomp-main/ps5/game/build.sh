#!/usr/bin/env bash
# Build the game for PS5 as a payload ELF: the recompiled code, the host
# sources that the recompiled code calls into (hooks), the PS5 host
# (main_ps5.cpp) and the runtime's static libraries. Milestone P4: no graphics.
#
# Run on the Arch host after the runtime has been built for PS5 (see
# docs/ps5-port-plan.md) and after codegen has produced generated/default on
# the PC side. Touches no console.
#
# Usage: build.sh [stage ...]     (default: 4)  -> $work/mcla-stage<N>.elf
# Environment: MCLA_RUN_SECONDS, MCLA_LOG_LEVEL, JOBS
#   MCLA_PLAY=1  a build for playing (see below)
#   MCLA_PROFILE_AT=<second>  take a 20 s sampling profile from that second
#   MCLA_TITLE_NAME=<name>  the name shown on the console (default "MCLA Stage <N>")
#   ART_DIR=<folder>  tile and backgrounds for the title (see ps5/title_build.sh)
#   TITLE=<TITLEID>  build an installable title instead (ps5/title_build.sh):
#                    <driver>/dist/<TITLEID>, one stage at a time
set -euo pipefail
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
repo=$(cd -- "$here/../.." && pwd)
driver=${PS5_VULKAN:-/root/ps5vk/PS5_Vulkan}
sdk="$driver/.deps/native/ps5-payload-sdk"
runtime_src=${REX_SRC:-/root/mcla/rexglue-sdk}
runtime_build=${REX_BUILD:-/root/mcla/build-ps5}
libs="$runtime_src/out/ps5-amd64"
work=${MCLA_PS5_WORK:-/root/mcla/game-ps5}
jobs=${JOBS:-$(nproc)}
cxx="$sdk/bin/prospero-clang++"
mkdir -p "$work/obj" "$work/src/generated" "$work/src/src" "$work/src/ps5"
# FSR 3.1 (untested on the console): FidelityFX's static libraries, when the
# runtime build made them (ps5/make_ps5.sh; MCLA_PS5_FSR=0 leaves FSR out). The
# GPU plugin refers to FidelityFX weakly, which pulls nothing out of an archive,
# so --undefined makes the link take them; if that link fails, the game is
# linked again without them, and FSR is then unavailable. Without them the
# plugin's weak references stay unresolved, never dynamic imports
# (nodynamic-undefined-weak).
fsr_archives=() runtime_archives=()
for archive in "$libs"/*.a; do
    case $(basename "$archive") in
        libamd_fidelityfx_*.a|libffx_*.a) fsr_archives+=("$archive") ;;
        *) runtime_archives+=("$archive") ;;
    esac
done
fsr=0
if [ "${MCLA_PS5_FSR:-1}" != 0 ] && [ -f "$libs/libamd_fidelityfx_vk.a" ]; then
    fsr=1
fi
fsr_fallback() {
    tail -20 "$1" >&2
    echo "warning: linking FidelityFX (FSR 3.1) failed (log: $1); linking again without it, so the game won't offer FSR. If the errors are in frame generation's code (ffx_frameinterpolation, ffx_opticalflow, the provider), build the runtime again with MCLA_PS5_FRAMEGEN=0 (ps5/make_ps5.sh) to keep FSR anti-aliasing" >&2
}

# A local copy of the sources: the repository is on a Windows drive here, which
# is slow to read 120 MB from for every compile and has CRLF line endings.
rsync -a --delete "$repo/generated/default/" "$work/src/generated/default/"
rsync -a --delete --include='*.cpp' --include='*.h' --exclude='*' "$repo/src/" "$work/src/src/"
tr -d '\r' < "$here/main_ps5.cpp" > "$work/src/ps5/main_ps5.cpp.new"
cmp -s "$work/src/ps5/main_ps5.cpp.new" "$work/src/ps5/main_ps5.cpp" 2>/dev/null \
    && rm "$work/src/ps5/main_ps5.cpp.new" \
    || mv "$work/src/ps5/main_ps5.cpp.new" "$work/src/ps5/main_ps5.cpp"
tr -d '\r' < "$here/ps5_pad_input.h" > "$work/src/ps5/ps5_pad_input.h"
tr -d '\r' < "$here/ps5_audio.h" > "$work/src/ps5/ps5_audio.h"
tr -d '\r' < "$here/ps5_haptics.h" > "$work/src/ps5/ps5_haptics.h"
tr -d '\r' < "$here/ps5_triggers.h" > "$work/src/ps5/ps5_triggers.h"
for header in title_log.h log_fd_sink.h; do
    tr -d '\r' < "$here/../$header" > "$work/src/ps5/$header"
done

# The runtime's own defines and include paths, taken from its build; its
# precompiled header and float model are not wanted for the game code.
ninja -C "$runtime_build" -t commands rexruntime > "$work/commands.txt"
# grep -m1, not "grep | head -1": under pipefail the latter fails now and then,
# when head exits before grep has finished writing.
command=$(grep -m1 'xmemory\.cpp\.o ' "$work/commands.txt")
inherited=$(printf '%s' "$command" | tr ' ' '\n' | grep -E '^(--sysroot=|-D|-I)' | grep -v -E '^-DNDEBUG$' | tr '\n' ' ')
inherited_system=$(printf '%s' "$command" | grep -o -E -- '-isystem [^ ]+' | tr '\n' ' ')
# -ffp-contract=off: the desktop build targets SSE4.1 and so never fuses a
# multiply and an add; with znver2 the compiler would, and guest floating
# point results would differ between the two builds.
flags="$inherited $inherited_system -march=znver2 -fexperimental-library -O3 -DNDEBUG -std=c++23 -fPIC \
  -mcmodel=large -fno-strict-aliasing -fno-char8_t -ffp-contract=off -g0 -w \
  -I$work/src -I$work/src/src -I$work/src/generated/default"
# Sources include "generated/default/mcla_init.h" relative to the repository root.
[ -e "$work/src/generated/default/mcla_init.h" ] || { echo "generated/default is missing; run codegen on the PC" >&2; exit 1; }
# The generated header has its own copy of the rule for the 0xE0000000 physical
# range's 4 KiB host offset, and it must name PS5 (16 KiB pages) as the runtime
# does. Without it the game code and the runtime disagree about where that
# memory is, and the game stalls waiting for a GPU that never sees its
# commands. The SDK patch fixes the codegen template; a header generated by an
# unpatched SDK does not have it.
grep -q 'REX_PLATFORM_WIN32 || (REX_PLATFORM_MAC && REX_ARCH_ARM64) || REX_PLATFORM_PS5' \
    "$work/src/generated/default/mcla_pch.h" \
    || { echo "mcla_pch.h lacks the PS5 physical host offset; regenerate with the patched SDK" >&2; exit 1; }

printf '%s' "$flags" > "$work/flags.new"
if ! cmp -s "$work/flags.new" "$work/flags.txt" 2>/dev/null; then
    rm -f "$work"/obj/*.o "$work"/obj/*.pch
    mv "$work/flags.new" "$work/flags.txt"
fi

pch="$work/obj/mcla_pch.h.pch"
# Does clang still accept the precompiled header? It refuses one when a header it read has another size or time ("file
# ... has been modified since the precompiled header ... was built"), which a patched SDK or a new checkout of it does
# to the headers outside generated/; the find below sees only the generated ones. Loading it for an
# empty file is the same test. (The same stale header stopped updates of the PC build, fork issue #23. Not run on a
# console: see KNOWN-ISSUES.md.)
if [ -e "$pch" ] && ! ( cd "$runtime_build" && eval "\"$cxx\" $flags -x c++ -include-pch \"$pch\" -fsyntax-only /dev/null" ) > "$work/pch-check.log" 2>&1; then
    echo "the precompiled header no longer loads ($(grep -m1 -i 'error' "$work/pch-check.log" | cut -c1-200 || true)); making it again"
    rm -f "$pch"
fi
if [ ! -e "$pch" ] || [ -n "$(find "$work/src/generated/default" -name '*.h' -newer "$pch" -print -quit)" ]; then
    echo "precompiling mcla_pch.h"
    ( cd "$runtime_build" && eval "\"$cxx\" $flags -x c++-header -o \"$pch\" -c \"$work/src/generated/default/mcla_pch.h\"" )
    rm -f "$work"/obj/gen_*.o
fi

# One compile per line, run in parallel; only what is out of date.
: > "$work/todo.txt"
for source in "$work"/src/generated/default/*.cpp; do
    object="$work/obj/gen_$(basename "$source" .cpp).o"
    [ "$object" -nt "$source" ] || printf '%s\t%s\t%s\n' "$source" "$object" "-include-pch $pch" >> "$work/todo.txt"
done
# The desktop-only sources are left out: mcla_app.cpp and main.cpp are the
# windowed host, and the code-pointer scan, crash trace and sampling profiler
# are development tools tied to it.
for name in audio_fallback audio_mixer frame_timing render_perf perf_options warp_fix button_prompts settings_menu save_wait display_gamma render_markers shader_prepare shader_storage_files vehicle_telemetry vibration; do
    source="$work/src/src/$name.cpp"
    object="$work/obj/host_$name.o"
    [ "$object" -nt "$source" ] && [ "$object" -nt "$work/src/src/mcla_app.h" ] && [ "$object" -nt "$pch" ] || printf '%s\t%s\t%s\n' "$source" "$object" "" >> "$work/todo.txt"
done
count=$(wc -l < "$work/todo.txt")
echo "compiling $count sources with $jobs jobs"
if [ "$count" -gt 0 ]; then
    export cxx flags runtime_build
    compile_one() {
        IFS=$'\t' read -r source object extra <<< "$1"
        ( cd "$runtime_build" && eval "\"$cxx\" $flags $extra -o \"$object\" -c \"$source\"" ) 2> "$object.log" \
            || { echo "FAILED $(basename "$source")"; head -20 "$object.log"; rm -f "$object"; return 1; }
        rm -f "$object.log"
    }
    export -f compile_one
    nice -n 10 xargs -a "$work/todo.txt" -d '\n' -P "$jobs" -I{} bash -c 'compile_one "$1"' _ {} || { echo "compile failed" >&2; exit 1; }
fi

bash "$here/../payload_ld.sh" write "$sdk" "$work/payload.ld"
stages=("$@"); [ ${#stages[@]} -gt 0 ] || stages=(4)
for stage in "${stages[@]}"; do
    extra="-DMCLA_STAGE=$stage"
    [ -z "${MCLA_RUN_SECONDS:-}" ] || extra="$extra -DMCLA_RUN_SECONDS=$MCLA_RUN_SECONDS"
    # A 20 s sampling profile starting this many seconds into the run
    # (ps5/profile_report.py reads it from the title log).
    [ -z "${MCLA_PROFILE_AT:-}" ] || extra="$extra -DMCLA_PROFILE_AT=$MCLA_PROFILE_AT"
    # Tuning of the write-tracking units (see main_ps5.cpp); defaults 0 and 16.
    [ -z "${MCLA_WATCH_GRANULARITY:-}" ] || extra="$extra -DMCLA_WATCH_GRANULARITY=$MCLA_WATCH_GRANULARITY"
    [ -z "${MCLA_REQUEST_GRANULARITY_LOG2:-}" ] || extra="$extra -DMCLA_REQUEST_GRANULARITY_LOG2=$MCLA_REQUEST_GRANULARITY_LOG2"
    [ -z "${MCLA_HOT_PAGE_FAULTS:-}" ] || extra="$extra -DMCLA_HOT_PAGE_FAULTS=$MCLA_HOT_PAGE_FAULTS"
    # MCLA_CLEAR_PAGE_STATE=true restores the runtime's per-frame re-copy of all pages in use.
    [ -z "${MCLA_CLEAR_PAGE_STATE:-}" ] || extra="$extra -DMCLA_CLEAR_PAGE_STATE=$MCLA_CLEAR_PAGE_STATE"
    # MCLA_SUBMIT_ON_BUFFER_END=true restores a submission at every end of the guest's primary buffer.
    [ -z "${MCLA_SUBMIT_ON_BUFFER_END:-}" ] || extra="$extra -DMCLA_SUBMIT_ON_BUFFER_END=$MCLA_SUBMIT_ON_BUFFER_END"
    # A tuning run: cycle through setting combinations every 30 s from this second.
    [ -z "${MCLA_TUNE_FROM:-}" ] || extra="$extra -DMCLA_TUNE_FROM=$MCLA_TUNE_FROM"
    # Log presents every second and profile 5 s whenever they fall below this many.
    [ -z "${MCLA_PROFILE_DIPS:-}" ] || extra="$extra -DMCLA_PROFILE_DIPS=$MCLA_PROFILE_DIPS"
    [ -z "${MCLA_PROFILE_DIPS_FROM:-}" ] || extra="$extra -DMCLA_PROFILE_DIPS_FROM=$MCLA_PROFILE_DIPS_FROM"
    [ -z "${MCLA_LOG_LEVEL:-}" ] || extra="$extra -DMCLA_LOG_LEVEL=\\\"$MCLA_LOG_LEVEL\\\""
    # MCLA_PLAY=1: a build for playing, not measuring. No wait for a log
    # connection (the log is /data/mcla/mcla-play.log on the console), no
    # periodic diagnostics, no time limit. Use it with MCLA_LOG_LEVEL=warning.
    [ -z "${MCLA_PLAY:-}" ] || extra="$extra -DMCLA_PLAY"
    if [ -n "${TITLE:-}" ]; then
        # As an installable title, linked with the Vulkan driver, log over TCP.
        ( cd "$runtime_build" && eval "\"$cxx\" $flags $extra -DMCLA_TITLE -I\"$work/src/ps5\" -o \"$work/obj/title_stage$stage.o\" -c \"$work/src/ps5/main_ps5.cpp\"" )
        title_link() {  # 1: with FidelityFX
            local options=() archives=()
            if [ "$1" = 1 ]; then
                options=(--undefined=ffxCreateContext) archives=("${fsr_archives[@]}")
            elif [ "${MCLA_PS5_FSR:-1}" != 0 ]; then
                options=(-z nodynamic-undefined-weak)
            fi
            bash "$here/../title_build.sh" "$TITLE" "${MCLA_TITLE_NAME:-MCLA Stage $stage}" \
                "$work/obj/title_stage$stage.o" "$work"/obj/gen_*.o "$work"/obj/host_*.o "${options[@]}" \
                --start-group "${runtime_archives[@]}" "${archives[@]}" "$sdk/target/lib/libc++experimental.a" --end-group
        }
        if [ "$fsr" = 1 ]; then
            if title_link 1 > "$work/fsr-link-stage$stage.log" 2>&1; then
                cat "$work/fsr-link-stage$stage.log"
            else
                fsr_fallback "$work/fsr-link-stage$stage.log"
                title_link 0
            fi
        else
            title_link 0
        fi
        continue
    fi
    ( cd "$runtime_build" && eval "\"$cxx\" $flags $extra -I\"$work/src/ps5\" -o \"$work/obj/main_stage$stage.o\" -c \"$work/src/ps5/main_ps5.cpp\"" )
    # The runtime's libraries as one group because they reference each other.
    # nodynamic-undefined-weak: see ps5/probes/arena/build.sh.
    payload_link() {  # 1: with FidelityFX
        local options=() archives=()
        if [ "$1" = 1 ]; then
            options=(-Wl,--undefined=ffxCreateContext) archives=("${fsr_archives[@]}")
        fi
        "$cxx" -Wl,-z,nodynamic-undefined-weak -Wl,-T,"$work/payload.ld" "${options[@]}" \
            -o "$work/mcla-stage$stage.elf" "$work/obj/main_stage$stage.o" "$work"/obj/gen_*.o "$work"/obj/host_*.o \
            -Wl,--start-group "${runtime_archives[@]}" "${archives[@]}" "$sdk/target/lib/libc++experimental.a" -Wl,--end-group
    }
    if [ "$fsr" = 1 ]; then
        if ! payload_link 1 > "$work/fsr-link-stage$stage.log" 2>&1; then
            fsr_fallback "$work/fsr-link-stage$stage.log"
            payload_link 0
        fi
    else
        payload_link 0
    fi
    bash "$here/../payload_ld.sh" check "$work/mcla-stage$stage.elf"
    ls -la "$work/mcla-stage$stage.elf"
done
